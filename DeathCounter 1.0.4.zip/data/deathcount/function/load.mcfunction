scoreboard objectives add deathcounts deathCount "⚰️ Death Count ⚰️"
scoreboard objectives modify deathcounts numberformat styled {"color":"gold"}
scoreboard objectives setdisplay list deathcounts
